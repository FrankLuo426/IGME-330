# IGME330P3
## UIUX

 In this project we redesign every elements UI to make it suitable for the whole project.  We really spend a lot of time to do all the effects here and we learn a lot in the website  how to write css. 

## Style

 We have four different kinds of styles for the visualizer  And the user can pick the one they like.  Also the user can change the parameters for each kind of style.

## INTRO
To bring a short introduction to this project, I would say this is a food project with a weather function.  Basically you can find restaurant in your location,  And you can get the weather Information for this location.  At first you just type in the location,  And then if you are lazy  you can just random food by weather,  And we will show you the weather there and show you the food we recommend,  If you don't want this food,  You can just roll another one.  And then the map will show you the location where the food is.  And of course  you can search for food in a location if you are not that lazy.
The background of the weather APP will be changed by the location.
 We use 4 API in this project.  The first one is the map box  which will show you the map.  The second one is yelp API  which will show you the restaurant.  We search for food and get the location in the coordinates way by the yelp API,  And then we get the Mark on the map.  The 3rd API is the open weather box API,  Which will show us the weather Information.  The fourth API is the unsplash API  which will search for an image of the city.
 Basically, The food function is made by John,  And the weather function is made by Frank.
